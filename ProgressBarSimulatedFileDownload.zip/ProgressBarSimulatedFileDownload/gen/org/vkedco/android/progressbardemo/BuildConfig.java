/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.android.progressbardemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}